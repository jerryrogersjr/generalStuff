package com.skilldistillery.login.controllers;

import org.springframework.stereotype.Controller;

@Controller
public class AccountController {

}
